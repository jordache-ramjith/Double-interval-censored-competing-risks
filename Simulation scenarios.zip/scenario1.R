
#N=200, beta1=0.1, beta2=-0.3, interval width=28 and maxt=200------------------

source("Simulation function.R")
source("model function.R")

nsim=500
maxt = 200
simdat = simulation(nsim=nsim,n=200,maxt=maxt,beta1=0.1,beta2=-0.3)
saveRDS(simplotdata,"data/simplotdata_N200_28days_t200.RDS")

i=1
c1=as.vector(NA)
c2=as.vector(NA)
c3=as.vector(NA)

for(i in 1:nsim){
  c1[i]=sum(simdat[[i]]$state==1)
  c2[i]=sum(simdat[[i]]$state==2)
  c3[i]=sum(simdat[[i]]$state==3)
  print(i)
}

sum(c1)/(200*nsim)
#2.1% right censored
sum(c2)/(200*nsim)
#37.8% event-of-interest
sum(c3)/(200*nsim)
#60.1% competing event


results.coefs=data.frame(m1beta1=NA,m1beta2=NA,
                         expbeta1=NA,expbeta2=NA,
                         weibeta1=NA,weibeta2=NA,
                         bs2beta1=NA, bs2beta2=NA)

results.SE=data.frame(m1se1=NA,m1se2=NA,
                      expse1=NA,expse2=NA,
                      weise1=NA,weise2=NA,
                      bs2se1=NA, bs2se2=NA)

gam.est = data.frame(gam1=NA,gam2=NA)

simdatcut = list()

bshaz = list()

for (i in 1:nsim){
  
  m1gam=coxph(Surv(t,gam_event)~x, data=simdat[[i]], id=id)
  m1res=coxph(Surv(t,res_event)~x, data=simdat[[i]], id=id)
  m1b1 = m1gam$coefficients[[1]]
  m1b2 = m1res$coefficients[[1]]
  m1se1 = sqrt(vcov(m1gam))
  m1se2 = sqrt(vcov(m1res))
  
  simdatcut[[i]] = simdat[[i]][simdat[[i]]$res_event!=1 | simdat[[i]]$overlap!=1,]

  out.exp=tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="exp",
                               start1=c(0.1),start2=c(0.1)), error=function(err) NA)
  out.wei=tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="wei",
                               start1=c(0.1,-4),start2=c(0.1,-4)), error=function(err) tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="wei",
                                                                                                            start1=c(0.01,-2),start2=c(0.01,-2)), error=function(err) NA))

  out.bs2=NA
  maxr=10
  run=1
  
  while(any(is.na(out.bs2)) & run<=maxr){
    
    out.bs2=tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="bs",start1=-abs(rnorm(10,mean=-5,2)),start2=-abs(rnorm(10,mean=-5,2)),pred=TRUE), error=function(err) tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="bs",start1=-abs(rnorm(10,mean=-3,2)),start2=-abs(rnorm(10,mean=-3,2)),pred=TRUE), error=function(err) NA))
    
    if(is.na(out.bs2)==T) {
      out.bs2=NA
    } else {
      if((any(is.nan(out.bs2$estimates$SE)) | any(out.bs2$estimates$SE<0.01))==T) {out.bs2=NA} else{print("YAY")}
    }
    print(run)
    run = run+1
  }
  
  
  if(is.na(out.bs2)==F) {
    out.bs2$fitdata$id=i
    gam.est[i,] = out.bs2$gam
  } else {
    gam.est[i,] = c(NA,NA)
    
  }
  
  
  bshaz[[i]]=tryCatch(out.bs2$fitdata, error=function(err) NA)
  

  expbeta1=tryCatch(out.exp$estimates$coef[[1]], error=function(err) NA)
  expse1=tryCatch(out.exp$estimates$SE[[1]], error=function(err) NA)
  weibeta1=tryCatch(out.wei$estimates$coef[[1]], error=function(err) NA)
  weise1=tryCatch(out.wei$estimates$SE[[1]], error=function(err) NA)
  bs2beta1=tryCatch(out.bs2$estimates$coef[[1]], error=function(err) NA)
  bs2se1=tryCatch(out.bs2$estimates$SE[[1]], error=function(err) NA)
  expbeta2=tryCatch(out.exp$estimates$coef[[2]], error=function(err) NA)
  expse2=tryCatch(out.exp$estimates$SE[[2]], error=function(err) NA)
  weibeta2=tryCatch(out.wei$estimates$coef[[2]], error=function(err) NA)
  weise2=tryCatch(out.wei$estimates$SE[[2]], error=function(err) NA)
  bs2beta2=tryCatch(out.bs2$estimates$coef[[2]], error=function(err) NA)
  bs2se2=tryCatch(out.bs2$estimates$SE[[2]], error=function(err) NA)
  
  results.coefs[i,]=t(c(m1beta1=m1b1,m1beta2=m1b2,
                        expbeta1=expbeta1,expbeta2=expbeta2,
                        weibeta1=weibeta1,weibeta2=weibeta2,
                        bs2beta1=bs2beta1, bs2beta2=bs2beta2))
  
  results.SE[i,]=t(c(m1se1=m1se1,m1se2=m1se2,
                     expse1=expse1,expse2=expse2,
                     weise1=weise1,weise2=weise2,
                     bs2se1=bs2se1, bs2se2=bs2se2))
  
  saveRDS(results.coefs,"data/mixed_N200_28days_t200_coefs.RDS")
  saveRDS(results.SE,"data/mixed_N200_28days_t200_se.RDS")
  saveRDS(gam.est,"data/gam_est_N200_28days_t200.RDS")
  saveRDS(bshaz,"data/bshaz_N200_28days_t200.RDS")

  print(i)
}

