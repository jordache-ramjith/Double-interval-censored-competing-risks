
#N=200, beta1=0.1, beta2=-0.3, interval width=28 and maxt=200------------------

source("Simulation function.R")
source("model function.R")

nsim=500
maxt = 200
simdat = simulation(nsim=nsim,n=200,maxt=maxt,beta1=0.1,beta2=-0.3,width=28)
saveRDS(simplotdata,"data/simplotdata_N200_28days_t200_k20_gam10.RDS")

i=1
c1=as.vector(NA)
c2=as.vector(NA)
c3=as.vector(NA)

for(i in 1:nsim){
  c1[i]=sum(simdat[[i]]$state==1)
  c2[i]=sum(simdat[[i]]$state==2)
  c3[i]=sum(simdat[[i]]$state==3)
  print(i)
}

sum(c1)/(100*nsim)
#2.1% right censored
sum(c2)/(100*nsim)
#37.8% event-of-interest
sum(c3)/(100*nsim)
#60.1% competing event

results.coefs <- readRDS("data/mixed_N200_28days_t200_k20_coefs.RDS")
results.SE=readRDS("data/mixed_N200_28days_t200_k20_se.RDS")

results.coefs$bs2beta1=NA
results.coefs$bs2beta2=NA
results.SE$bs2se1=NA
results.SE$bs2se2=NA

gam.est = data.frame(gam1=NA,gam2=NA)
simdatcut = list()
bshaz = list()

for (i in 1:nsim){
  
  simdatcut[[i]] = simdat[[i]][simdat[[i]]$res_event!=1 | simdat[[i]]$overlap!=1,]
  
  out.bs2=NA
  maxr=10
  run=1
  
  while(any(is.na(out.bs2)) & run<=maxr){
    
    out.bs2=tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="bs",start1=-abs(rnorm(20,mean=-5,2)),start2=-abs(rnorm(20,mean=-5,2)),gam=c(10,10),k=20,pred=TRUE), error=function(err) tryCatch(cr.interval(data=simdatcut[[i]],covs=c("x"),method="bs",start1=-abs(rnorm(20,mean=-3,2)),start2=-abs(rnorm(20,mean=-3,2)),gam=c(10,10),k=20,pred=TRUE), error=function(err) NA))
    
    if(is.na(out.bs2)==T) {
      out.bs2=NA
    } else {
      if((any(is.nan(out.bs2$estimates$SE)) | any(out.bs2$estimates$SE<0.01))==T) {out.bs2=NA} else{print("YAY")}
    }
    print(run)
    run = run+1
  }
  
  
  if(is.na(out.bs2)==F) {
    out.bs2$fitdata$id=i
    gam.est[i,] = out.bs2$gam
  } else {
    gam.est[i,] = c(NA,NA)
    
  }
  
  
  bshaz[[i]]=tryCatch(out.bs2$fitdata, error=function(err) NA)
  
  
  results.coefs[i,]$bs2beta1=tryCatch(out.bs2$estimates$coef[[1]], error=function(err) NA)
  results.SE[i,]$bs2se1=tryCatch(out.bs2$estimates$SE[[1]], error=function(err) NA)
  results.coefs[i,]$bs2beta2=tryCatch(out.bs2$estimates$coef[[2]], error=function(err) NA)
  results.SE[i,]$bs2se2=tryCatch(out.bs2$estimates$SE[[2]], error=function(err) NA)
  
  
  saveRDS(results.coefs,"data/mixed_N200_28days_t200_k20_gam10_coefs.RDS")
  saveRDS(results.SE,"data/mixed_N200_28days_t200_k20_gam10_se.RDS")
  saveRDS(gam.est,"data/gam_est_N200_28days_t200_k20_gam10.RDS")
  saveRDS(bshaz,"data/bshaz_N200_28days_t200_k20_gam10.RDS")

  print(i)
  
  View(gam.est)
  View(results.coefs)
  View(results.SE)
  
  
  
  print(ggarrange(
    ggplot(results.coefs[1:i,], aes(x=m1beta1,y=expbeta1))+
      geom_point()+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red")+
      theme_prism()+
      coord_cartesian(xlim=c(-1,1),ylim=c(-1,1))+
      ggtitle(expression(beta[1]))+
      xlab("CPH")+
      ylab("Exponential"),
    
    
    ggplot(results.coefs[1:i,], aes(x=m1beta1,y=weibeta1))+
      geom_point()+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red")+
      theme_prism()+
      coord_cartesian(xlim=c(-1,1),ylim=c(-1,1))+
      ggtitle(expression(beta[1]))+
      xlab("CPH")+
      ylab("Weibull"),
    
    ggplot(results.coefs[1:i,], aes(x=m1beta1,y=bs2beta1))+
      geom_point()+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red")+
      theme_prism()+
      coord_cartesian(xlim=c(-1,1),ylim=c(-1,1))+
      ggtitle(expression(beta[1]))+
      ylab("Spline")+
      xlab("CPH"),
    
    
    ### beta2
    
    
    ggplot(results.coefs[1:i,], aes(x=m1beta2,y=expbeta2))+
      geom_point()+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red")+
      theme_prism()+
      coord_cartesian(xlim=c(-1.5,0.5),ylim=c(-1.5,0.5))+
      ggtitle(expression(beta[2]))+
      xlab("CPH")+
      ylab("Exponential"),
    
    
    ggplot(results.coefs[1:i,], aes(x=m1beta2,y=weibeta2))+
      geom_point()+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red")+
      theme_prism()+
      coord_cartesian(xlim=c(-1.5,0.5),ylim=c(-1.5,0.5))+
      ggtitle(expression(beta[2]))+
      xlab("CPH")+
      ylab("Weibull"),
    
    
    ggplot(results.coefs[1:i,], aes(x=m1beta2,y=bs2beta2))+
      geom_point()+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red")+
      theme_prism()+
      coord_cartesian(xlim=c(-1.5,0.5),ylim=c(-1.5,0.5))+
      ggtitle(expression(beta[2]))+
      ylab("Spline")+
      xlab("CPH"),
    
    nrow=2, ncol=3,labels=c("A.","B.","C.","D.","E.","F.")))
  
  
  print(ggarrange(
    ggplot(results.SE[1:i,], aes(x=m1se1,y=expse1))+
      geom_point(alpha=0.7)+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red",alpha=0.5)+
      theme_prism()+
      coord_cartesian(xlim=c(0.15,0.5),ylim=c(0.15,0.5))+
      ggtitle(expression(SE[1]))+
      ylab("Exponential")+
      xlab("CPH"),
    
    ggplot(results.SE[1:i,], aes(x=m1se1,y=weise1))+
      geom_point(alpha=0.7)+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red",alpha=0.5)+
      theme_prism()+
      coord_cartesian(xlim=c(0.15,0.5),ylim=c(0.15,0.5))+
      ggtitle(expression(SE[1]))+
      ylab("Weibull")+
      xlab("CPH"),
    
    
    ggplot(results.SE[1:i,], aes(x=m1se1,y=bs2se1))+
      geom_point(alpha=0.7)+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red",alpha=0.5)+
      theme_prism()+
      coord_cartesian(xlim=c(0.15,0.5),ylim=c(0.15,0.5))+
      ggtitle(expression(SE[1]))+
      ylab("Spline")+
      xlab("CPH"),
    
    
    ### se2
    
    
    ggplot(results.SE[1:i,], aes(x=m1se2,y=expse2))+
      geom_point(alpha=0.7)+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red",alpha=0.5)+
      theme_prism()+
      coord_cartesian(xlim=c(0.15,0.5),ylim=c(0.15,0.5))+
      ggtitle(expression(SE[2]))+
      ylab("Exponential")+
      xlab("CPH"),
    
    ggplot(results.SE[1:i,], aes(x=m1se2,y=weise2))+
      geom_point(alpha=0.7)+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red",alpha=0.5)+
      theme_prism()+
      coord_cartesian(xlim=c(0.15,0.5),ylim=c(0.15,0.5))+
      ggtitle(expression(SE[2]))+
      ylab("Weibull")+
      xlab("CPH"),
    
    
    ggplot(results.SE[1:i,], aes(x=m1se2,y=bs2se2))+
      geom_point(alpha=0.7)+
      geom_smooth(method="lm",se=FALSE)+
      geom_abline(slope=1,intercept=0,col="red",alpha=0.5)+
      theme_prism()+
      coord_cartesian(xlim=c(0.15,0.5),ylim=c(0.15,0.5))+
      ggtitle(expression(SE[2]))+
      ylab("Spline")+
      xlab("CPH"),
    
    nrow=2, ncol=3,labels=c("A.","B.","C.","D.","E.","F.")))
  
  
  print(lm(results.coefs$bs2beta2~results.coefs$m1beta2))
  print(lm(results.SE$bs2se2~results.SE$m1se2))
  
  print(paste("Cox:",mean(results.coefs$m1beta2[1:i],na.rm=T)+0.3))
  print(paste("exp:",mean(results.coefs$expbeta2[1:i],na.rm=T)+0.3))
  print(paste("wei:",mean(results.coefs$weibeta2[1:i],na.rm=T)+0.3))
  print(paste("bs:",mean(results.coefs$bs2beta2[1:i],na.rm=T)+0.3))
  print(paste("bs-cox:",mean(results.coefs$bs2beta2[1:i],na.rm=T)-mean(results.coefs$m1beta2[1:i],na.rm=T)))
  
}

